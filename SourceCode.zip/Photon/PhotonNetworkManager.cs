using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using Photon.Realtime;
using Photon.Pun;
using IEnumerator = System.Collections.IEnumerator;
using Unity.Collections;
using ExitGames.Client.Photon;
using Opsive;


public class PhotonNetworkManager : MonoBehaviourPunCallbacks
{
#region InputField
    [Header("Connection Status")]
        public Text connectionStatusText;

    // [Header("Login UI Panel")]
    //     public InputField PlayerNameInputField;
    //     public GameObject Login_UI_Panel;
    //     public GameObject InvalidLoginPanel;

    [Header("Game Options UI Panel")]
        public GameObject GameOptions_UI_Panel;

    [Header("Create Room UI")] 
        public InputField roomNameInputField;
        // public InputField maxPlayersInputField;
        public GameObject InvalidRoomName; 

        // public Image roomNameImage;
        // bool isRoomNameValid = false;

    [Header("Inside Room UI Panel")]
        public GameObject InsideRoom_UI_Panel;
        public Text roomInfoText;
        // public Text RoomNameText;
        // public Text PlayerCountText;
        // public Text MaxPlayerText;
        public GameObject playerListPrefab;
        public GameObject startGameButton;
        public GameObject playerListContent;

        //todo
        public GameObject playerListBlue;
        public GameObject playerListRed;

    [Header("Room List UI")]
        public GameObject roomListEntryPrefab;
        public GameObject roomListParentGameObject;

        // [Header("Room Name")]
        // public string mapName;

    [Header("Guides Panel UI")]
        public GameObject Guides_UI_Panel;

    [Header("Load Scene Level")]

        public GameObject LoadingScenePanel;
        public GameObject LoadingSceneActive;
        public GameObject Select_Map_Panel;
        [SerializeField] public string WarZoneMap;
        [SerializeField] public string TheHeritageMap;

    private Dictionary<string, RoomInfo> cachedRoomList;
    private Dictionary<string, GameObject> roomListGameObject;
    private Dictionary<int, GameObject> playerListGameObjects;

    // private Dictionary<int, GameObject> LoadingSceneGameObject;

    public static int myTeam;
    private GameObject playerObject;

    #endregion



#region Unity Methods
        private void Awake()
        {
            PhotonNetwork.AutomaticallySyncScene = true;

        }

        void Start()
        {
            // ActivePanel(Login_UI_Panel.name);
            ActivePanel(GameOptions_UI_Panel.name);

            InitialHash();

            cachedRoomList = new Dictionary<string, RoomInfo>();
            roomListGameObject = new Dictionary<string, GameObject>();

            ConnectToPhoton();
        }

        private void InitialHash()
        {
            ExitGames.Client.Photon.Hashtable playerProps = new ExitGames.Client.Photon.Hashtable
            {
                { "Team", 0}
            };
            PhotonNetwork.LocalPlayer.SetCustomProperties(playerProps);
            myTeam = 0;

            ExitGames.Client.Photon.Hashtable blueScore = new ExitGames.Client.Photon.Hashtable
            {
                { "BlueScore", 0}
            };
            PhotonNetwork.LocalPlayer.SetCustomProperties(blueScore);

            ExitGames.Client.Photon.Hashtable redScore = new ExitGames.Client.Photon.Hashtable
            {
                { "RedScore", 0}
            };
            PhotonNetwork.LocalPlayer.SetCustomProperties(redScore);
        }

        void Update()
    {
        // Status koneksi 
        connectionStatusText.text = "Connection status: " + PhotonNetwork.NetworkClientState;
    }
    #endregion

    #region UI Callbacks

        #region Login
            #region LoginPanel > HIDE
    //         public void OnloginButtonClicked()
    //         {
    //             string playerName = PlayerNameInputField.text;
    //             if (!string.IsNullOrEmpty(playerName))
    //             {
    //                 PhotonNetwork.LocalPlayer.NickName = playerName;
    //                 PhotonNetwork.ConnectUsingSettings();

    //             }
    //             else
    //             {
    //                 InvalidLoginPanel.SetActive(true);
    //                 Debug.Log("Invalid Player Name !");
    //             }
    //         }

    //         public void OnInvalidPlayerNameButtonOkClicked()
    // {
    //     InvalidLoginPanel.SetActive(false);
    // }
        #endregion

    #endregion
    
        #region Room Config
            public void OnRefreshRoomListButtonClicked()
            {
                if (!PhotonNetwork.InLobby)
                {
                    Debug.Log("Joined to lobby");
                    PhotonNetwork.JoinLobby();
                }
            }
            
            public void OnCreateRoomButtonClicked()
            {
                string roomName;
                roomName = roomNameInputField.text;
            
                //mengatur konfigurasi room
                // RoomOptions roomOptions = new RoomOptions();

                // if ((int.Parse(maxPlayersInputField.text) > 10 || int.Parse(maxPlayersInputField.text) <= 1))
                // {
                //     maxPlayersInputField.text = "Must be 2 - 10 players";
                //     return;
                // }

                // roomOptions.MaxPlayers = (byte)int.Parse(maxPlayersInputField.text);
                

                // * Dapat dikustomasi nanti
                // roomOptions.IsVisible = true;
                // roomOptions.IsOpen = true;

                //membuat room
                // PhotonNetwork.CreateRoom(roomName, roomOptions);

                if (string.IsNullOrEmpty(roomName))
                {
                    InvalidRoomName.SetActive(true);
                    Debug.Log("Room name is invalid");
                    return;
                }
                else{
                RoomOptions roomOptions = new RoomOptions();
                roomOptions.MaxPlayers = 10;

                PhotonNetwork.CreateRoom(roomName, roomOptions);
                }
            }

            public void OnInvalidRoomNameButtonOKClicked()
    {
        InvalidRoomName.SetActive(false);
    }

    #endregion

    public void OnBackButtonClicked()
    {
        if (PhotonNetwork.InLobby)
        {
            PhotonNetwork.LeaveLobby();
        }

        SceneManager.LoadScene("LoginScene");
    }

    public void ConnectToPhoton()
    {
        string playerName = PlayerPrefs.GetString("USER_NAME");

        //if player name is valid
        if(!string.IsNullOrEmpty(playerName))
        {
            //set player name
            PhotonNetwork.LocalPlayer.NickName = playerName;
            PhotonNetwork.ConnectUsingSettings();
        }
        else
        {
            Debug.Log("Player name is invalid");
        }
    }
    public void OnLeaveButtonClicked()
    {
        PhotonNetwork.LeaveRoom();
        roomNameInputField.text = "";
    }

    public void OnStartGameButtonClicked()
    {
        ActivePanel(Select_Map_Panel.name);
        // if (PhotonNetwork.IsMasterClient)
        // {
        //     PhotonNetwork.LoadLevel(mapName);
        // }
    }

    //Pilih Map
    public void OnWarZoneButtonClicked()
    {
        if(PhotonNetwork.IsConnectedAndReady)
        {
            GameObject LoadingSceneGameObject = Instantiate(LoadingScenePanel);

            LoadingSceneGameObject.transform.SetParent(LoadingSceneActive.transform);
            LoadingSceneGameObject.transform.localScale = Vector3.one;

            if (PhotonNetwork.IsMasterClient)
            {

                Debug.Log("Loading the level.");
                SceneManager.LoadScene(WarZoneMap);
                // PhotonNetwork.LoadLevel(WarZoneMap);
            }
        }
        // ActivePanel(LoadingScenePanel.name);

        

    }

    public void OnTheHeritageButtonClicked()
    {
        // ActivePanel(LoadingScenePanel.name);
        GameObject LoadingSceneGameObject = Instantiate(LoadingScenePanel);

        LoadingSceneGameObject.transform.SetParent(LoadingSceneActive.transform);
        LoadingSceneGameObject.transform.localScale = Vector3.one;

        if (PhotonNetwork.IsMasterClient)
        {
            Debug.Log("Loading the level.");
            // SceneManager.LoadSceneAsync("LoadingScene");
            PhotonNetwork.LoadLevel(TheHeritageMap);
            // canvas.gameObject.SetActive(true);
            // StartCoroutine(TheHeritageLoad(TheHeritageMap));
        }
    }

    public void BackToRoomButtonClicked()
    {
        ActivePanel(InsideRoom_UI_Panel.name);
    }

    //clicked by a button with dynamic variable for what team to join
    public void OnJoinTeamButtonClicked(int team)
    {
        if (PhotonNetwork.LocalPlayer.CustomProperties.ContainsKey("Team"))
        {
            ExitGames.Client.Photon.Hashtable playerProps = new ExitGames.Client.Photon.Hashtable
            {
                { "Team", team}
            };
            PhotonNetwork.LocalPlayer.SetCustomProperties(playerProps);

            Debug.Log("Player joined to team: " + team);
            myTeam = team;
            SetTeamParent(team);
        }
        else
        {
            ExitGames.Client.Photon.Hashtable playerProps = new ExitGames.Client.Photon.Hashtable
            {
                { "Team", team}
            };

            myTeam = team;
            PhotonNetwork.LocalPlayer.SetCustomProperties(playerProps);
            Debug.Log("Player is not in a team");
            SetTeamParent(team);
        }
    }

    public void OnGuideButtonClicked()
    {
        ActivePanel(Guides_UI_Panel.name);
    }

    public void OnOkGuideButtonClicked()
    {
        ActivePanel(GameOptions_UI_Panel.name);
    }
    public override void OnPlayerPropertiesUpdate(Player targetPlayer, ExitGames.Client.Photon.Hashtable changedProps)
    {
        GameObject playerListGameObject;
        if (playerListGameObjects.TryGetValue(targetPlayer.ActorNumber, out playerListGameObject))
        {
            object team;
            if (changedProps.TryGetValue("Team", out team))
            {
                if ((int)team == 0)
                {
                    playerListGameObject.transform.SetParent(playerListBlue.transform);
                    playerListGameObject.transform.localScale = Vector3.one;
                }
                else
                {
                    playerListGameObject.transform.SetParent(playerListRed.transform);
                    playerListGameObject.transform.localScale = Vector3.one;
                }

            }
        }
    }


    #endregion

    #region Photon Callbacks
    //Koneksi ke internet
    public override void OnConnected()
    {
        Debug.Log("Connected to Internet");
    }
    //Koneksi ke photon server
    public override void OnConnectedToMaster()
    {
        Debug.Log(PhotonNetwork.LocalPlayer.NickName + " connected to Photon Server");
        ActivePanel(GameOptions_UI_Panel.name);
    }
    //Ketika room berhasil dibuat
    public override void OnCreatedRoom()
    {
        Debug.Log(PhotonNetwork.CurrentRoom.Name + " is created");
    }
    //Ketika berhasil masuk ke dalam room
    public override void OnJoinedRoom()
    {
        Debug.Log(PhotonNetwork.LocalPlayer.NickName + " Joined to " + PhotonNetwork.CurrentRoom.Name);
        //set team
        Debug.Log("Team: " + PhotonNetwork.LocalPlayer.CustomProperties["Team"]);

        ActivePanel(InsideRoom_UI_Panel.name);

        //cek apakah kita adalah master client
        if (PhotonNetwork.LocalPlayer.IsMasterClient)
        {
            startGameButton.SetActive(true);
        }
        else
        {
            startGameButton.SetActive(false);
        }

        roomInfoText.text = "Room name    : " + PhotonNetwork.CurrentRoom.Name + "\n" +
                            "\nPlayer Count : " + PhotonNetwork.CurrentRoom.PlayerCount + "\n" +
                            "\nMax Players  : " + PhotonNetwork.CurrentRoom.MaxPlayers;
        

        if (playerListGameObjects == null)
        {
            playerListGameObjects = new Dictionary<int, GameObject>();
        }

        // melakukan instansi player list gameobjects
        foreach (Player player in PhotonNetwork.PlayerList)
        {
            GameObject playerListGameObject = Instantiate(playerListPrefab);

            object currTeam;
            //instantiate player base on team
            if (player.CustomProperties.TryGetValue("Team", out currTeam))
            {
                if ((int)currTeam == 0)
                {
                    playerListGameObject.transform.SetParent(playerListBlue.transform);
                    playerListGameObject.transform.localScale = Vector3.one;
                }
                else if ((int)currTeam == 1)
                {
                    playerListGameObject.transform.SetParent(playerListRed.transform);
                    playerListGameObject.transform.localScale = Vector3.one;
                }
            }
            else
            {
                Debug.Log("Player is not in a team");
            }


            playerListGameObject.transform.Find("PlayerNameText").GetComponent<Text>().text = player.NickName;

            if (player.ActorNumber == PhotonNetwork.LocalPlayer.ActorNumber)
            {
                playerListGameObject.transform.Find("PlayerIndicator").gameObject.SetActive(true);
            }
            else
            {
                playerListGameObject.transform.Find("PlayerIndicator").gameObject.SetActive(false);
            }

            if (player.ActorNumber == PhotonNetwork.LocalPlayer.ActorNumber)
            {
                playerObject = playerListGameObject;
            }

            playerListGameObjects.Add(player.ActorNumber, playerListGameObject);
        }

    }
    //Ketika ada player baru yang join ke dalam room
    public override void OnPlayerEnteredRoom(Player newPlayer)
    {
        //update room info text 
        roomInfoText.text = "Room name: " + PhotonNetwork.CurrentRoom.Name + " " +
                           "Players/Max.players: " +
                           PhotonNetwork.CurrentRoom.PlayerCount + "/" +
                           PhotonNetwork.CurrentRoom.MaxPlayers;

        GameObject playerListGameObject = Instantiate(playerListPrefab);

        object currTeam;
        if (newPlayer.CustomProperties.TryGetValue("Team", out currTeam))
        {
            if ((int)currTeam == 0)
            {
                playerListGameObject.transform.SetParent(playerListBlue.transform);
                playerListGameObject.transform.localScale = Vector3.one;
            }
            else
            {
                playerListGameObject.transform.SetParent(playerListRed.transform);
                playerListGameObject.transform.localScale = Vector3.one;
            }
            // playerListGameObject.transform.SetParent(playerListRed.transform);
            // playerListGameObject.transform.localScale = Vector3.one;
        }

        playerListGameObject.transform.Find("PlayerNameText").GetComponent<Text>().text = newPlayer.NickName;

        if (newPlayer.ActorNumber == PhotonNetwork.LocalPlayer.ActorNumber)
        {
            playerListGameObject.transform.Find("PlayerIndicator").gameObject.SetActive(true);
        }
        else
        {
            playerListGameObject.transform.Find("PlayerIndicator").gameObject.SetActive(false);
        }



        playerListGameObjects.Add(newPlayer.ActorNumber, playerListGameObject);
    }
    //Ketika ada player yang leave dari room
    public override void OnPlayerLeftRoom(Player otherPlayer)
    {
        //update room info text 
        roomInfoText.text = "Room name: " + PhotonNetwork.CurrentRoom.Name + " " +
                           "Players/Max.players: " +
                           PhotonNetwork.CurrentRoom.PlayerCount + "/" +
                           PhotonNetwork.CurrentRoom.MaxPlayers;

        Destroy(playerListGameObjects[otherPlayer.ActorNumber].gameObject);
        playerListGameObjects.Remove(otherPlayer.ActorNumber);

        if (PhotonNetwork.LocalPlayer.IsMasterClient)
        {
            startGameButton.SetActive(true);
        }

    }
    //Ketika player keluar dari room
    public override void OnLeftRoom()
    {
        ActivePanel(GameOptions_UI_Panel.name);

        foreach (GameObject playerListGameobject in playerListGameObjects.Values)
        {
            Destroy(playerListGameobject);
        }

        playerListGameObjects.Clear();
        playerListGameObjects = null;

    }

    //Ketika room list update
    public override void OnRoomListUpdate(List<RoomInfo> roomList)
    {
        Debug.Log("Room List Updated");
        ClearRoomListView();

        foreach (RoomInfo room in roomList)
        {
            Debug.Log(room.Name);
            if (!room.IsOpen || !room.IsVisible || room.RemovedFromList)
            {
                if (cachedRoomList.ContainsKey(room.Name))
                {
                    cachedRoomList.Remove(room.Name);
                }
            }
            else
            {
                //update cachedRoom list
                if (cachedRoomList.ContainsKey(room.Name))
                {
                    cachedRoomList[room.Name] = room;
                }
                //add the new room to the cached room list
                else
                {
                    cachedRoomList.Add(room.Name, room);
                }
            }
        }

        foreach (RoomInfo room in cachedRoomList.Values)
        {
            GameObject roomListEntryGameObject = Instantiate(roomListEntryPrefab);
            Debug.Log("Room parented");
            roomListEntryGameObject.transform.SetParent(roomListParentGameObject.transform);
            roomListEntryGameObject.transform.localScale = Vector3.one;

            roomListEntryGameObject.transform.Find("RoomNameText").GetComponent<Text>().text = room.Name;
            roomListEntryGameObject.transform.Find("RoomPlayersText").GetComponent<Text>().text = room.PlayerCount + "/" + room.MaxPlayers;
            roomListEntryGameObject.transform.Find("JoinRoomButton").GetComponent<Button>().onClick.AddListener(() => OnJoinRoomButtonClicked(room.Name));

            //tidak mengizinkan untuk join jik sudah full
            if (room.PlayerCount == room.MaxPlayers)
            {
                roomListEntryGameObject.transform.Find("JoinRoomButton").GetComponent<Button>().interactable = false;
                roomListEntryGameObject.transform.Find("JoinRoomButton").GetComponent<Button>().GetComponentInChildren<Text>().text = "Full";
            }

            roomListGameObject.Add(room.Name, roomListEntryGameObject);
        }

    }
    //Ketika keluar dari lobby
    public override void OnLeftLobby()
    {
        ClearRoomListView();
        cachedRoomList.Clear();
    }

    #endregion

    #region Private Methods
    void OnJoinRoomButtonClicked(string _roomName)
    {

        if (PhotonNetwork.InLobby)
        {
            PhotonNetwork.LeaveLobby();
        }

        PhotonNetwork.JoinRoom(_roomName);
    }

    void ClearRoomListView()
    {
        foreach (var roomListGameObject in roomListGameObject.Values)
        {
            Destroy(roomListGameObject);
        }

        roomListGameObject.Clear();
    }

    private void SetTeamParent(int team)
    {
        if (team == 0)
        {
            playerObject.transform.SetParent(playerListBlue.transform);
            playerObject.transform.localScale = Vector3.one;
        }
        else
        {
            playerObject.transform.SetParent(playerListRed.transform);
            playerObject.transform.localScale = Vector3.one;
        }
    }
    #endregion

    #region Public Methods
    public void ActivePanel(string panelToBeActivated)
    {
        // LoadingScenePanel.SetActive(panelToBeActivated.Equals(LoadingScenePanel.name));
        Guides_UI_Panel.SetActive(panelToBeActivated.Equals(Guides_UI_Panel.name));
        // Login_UI_Panel.SetActive(panelToBeActivated.Equals(Login_UI_Panel.name));
        GameOptions_UI_Panel.SetActive(panelToBeActivated.Equals(GameOptions_UI_Panel.name));
        InsideRoom_UI_Panel.SetActive(panelToBeActivated.Equals(InsideRoom_UI_Panel.name));
        Select_Map_Panel.SetActive(panelToBeActivated.Equals(Select_Map_Panel.name));
    }
    #endregion
}
